package com.ll.k8s;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class K8sApplicationTests {

	@Test
	void contextLoads() {
	}

}
